core:import("CoreMissionScriptElement")
ElementRelativeTeleportTarget = ElementRelativeTeleportTarget or class(CoreMissionScriptElement.MissionScriptElement)

-- ElementRelativeTeleportTarget Element
-- Creator: Cpone