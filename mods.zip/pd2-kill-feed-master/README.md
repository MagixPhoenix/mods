# pd2-kill-feed
BLT mod for showing a customizable kill feed
